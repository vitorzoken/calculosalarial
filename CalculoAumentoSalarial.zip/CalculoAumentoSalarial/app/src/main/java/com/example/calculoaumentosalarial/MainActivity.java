package com.example.calculoaumentosalarial;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etSalario;
    private RadioGroup rgAumento;
    private Button btnCalcular;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSalario = findViewById(R.id.etSalario);
        rgAumento = findViewById(R.id.rgAumento);
        btnCalcular = findViewById(R.id.btnCalcular);
        tvResultado = findViewById(R.id.tvResultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularNovoSalario();
            }
        });
    }

    private void calcularNovoSalario() {
        String salarioStr = etSalario.getText().toString();

        if (salarioStr.isEmpty()) {
            Toast.makeText(this, "Por favor, digite seu salário atual", Toast.LENGTH_SHORT).show();
            return;
        }

        double salarioAtual = Double.parseDouble(salarioStr);
        int selectedId = rgAumento.getCheckedRadioButtonId();

        if (selectedId == -1) {
            Toast.makeText(this, "Por favor, selecione um percentual de aumento", Toast.LENGTH_SHORT).show();
            return;
        }

        double percentual = 0;
        RadioButton radioButton = findViewById(selectedId);

        if (radioButton.getId() == R.id.rb40) {
            percentual = 0.40;
        } else if (radioButton.getId() == R.id.rb45) {
            percentual = 0.45;
        } else if (radioButton.getId() == R.id.rb50) {
            percentual = 0.50;
        }

        double aumento = salarioAtual * percentual;
        double novoSalario = salarioAtual + aumento;

        String resultado = String.format(
                "Salário atual: R$ %.2f\n" +
                        "Aumento: R$ %.2f (%.0f%%)\n" +
                        "Novo salário: R$ %.2f",
                salarioAtual, aumento, percentual * 100, novoSalario);

        tvResultado.setText(resultado);
        tvResultado.setVisibility(View.VISIBLE);
    }
}